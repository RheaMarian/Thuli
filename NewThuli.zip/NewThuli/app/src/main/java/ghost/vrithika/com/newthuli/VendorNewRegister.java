package ghost.vrithika.com.newthuli;

        import android.content.Context;
        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.AdapterView;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Spinner;
        import android.widget.TextView;

        import com.google.firebase.database.DataSnapshot;
        import com.google.firebase.database.DatabaseError;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.google.firebase.database.ValueEventListener;

        import java.util.ArrayList;
        import java.util.List;

public class VendorNewRegister extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_new_register);
        Intent intent=getIntent();
        final String utype=intent.getStringExtra("usertype");
        final String city=intent.getStringExtra("city");
        final String uid=intent.getStringExtra("uid");
        final String ps=intent.getStringExtra("ps");

        final DatabaseReference mFirebaseDatabase;
        final FirebaseDatabase mFirebaseInstance;

        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference("LicensedVendors");

        final EditText li=(EditText) findViewById(R.id.eli);
        final EditText name=(EditText) findViewById(R.id.ename);
        final EditText ph=(EditText) findViewById(R.id.eph);

        Spinner spinner = (Spinner) findViewById(R.id.szone);

        TextView ctv=(TextView)findViewById(R.id.details);

        // Spinner click listener
        spinner.setOnItemSelectedListener(this);
        List<String> categories = new ArrayList<String>();
        if(city.equalsIgnoreCase("Chennai"))
        {

            categories.add("Thiruvottiyur");
            categories.add("Manali");
            categories.add("Madhavaram");
            categories.add("Tondiarpet");
            categories.add("Royapuram");
            categories.add("Thiruvikanagar");
            categories.add("Ambattur");
            categories.add("Annanagar");
            categories.add("Teynampet");
            categories.add("Kodambakkam");
            categories.add("Valasaravakkam");
            categories.add("Alandur");
            categories.add("Adyar");
            categories.add("Perungudi");
            categories.add("Sholinganallur");
        }

        if(city.equalsIgnoreCase("Mumbai"))
        {
            categories.add("Mumbai");
        }

        if(city.equalsIgnoreCase("Kolkata"))
        {
            categories.add("Kolkata");
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);


        final Context context=this;

        Button benter=(Button)findViewById(R.id.benter);
        benter.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Spinner spinner=(Spinner)findViewById(R.id.szone);
                final String zone=spinner.getSelectedItem().toString();

               final Intent intent=new Intent(context,VendorInstruction.class);


                int flag=2;


                //INSERT CODE TO CHECK FOR LICENSE
                final String uname=name.getText().toString();
                final String uli=li.getText().toString();
                final String uph=ph.getText().toString();
                mFirebaseDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snap) {
                        LicensedVendors lvendor=null;
                        int flag=2;
                        String inst;
                        for(DataSnapshot singleSnapshot : snap.getChildren()){
                            //for(DataSnapshot s:singleSnapshot.getChildren()) {
                            lvendor = singleSnapshot.getValue(LicensedVendors.class);
                            if((uli.equals(lvendor.id))&&(uname.equals(lvendor.name))&&(uph.equals(lvendor.phno))){

                                DatabaseReference mFirebaseDatabase = mFirebaseInstance.getReference("Vendors");
                                String userId = mFirebaseDatabase.push().getKey();
                                NewVendor nvendor = new NewVendor(uid,ps,"0");
                                mFirebaseDatabase.child(userId).setValue(nvendor);

                                DatabaseReference mFirebaseDatabase1 = mFirebaseInstance.getReference(zone);
                                String userId1 = mFirebaseDatabase1.push().getKey();
                                Vendor vendor=new Vendor(uid,ps);
                                mFirebaseDatabase1.child(userId1).setValue(vendor);
                                flag=1;


                            }
                        }

                        if(flag==1)
                        {
                            inst="INSTRUCTIONS\n" +
                                    "\n" +
                                    "1.Each booking id will have unique password entered by customer only. Only then your delivery will be registered\n" +
                                    "2.Attempts to guess and enter password won't be encouraged\n" +
                                    "3.Collection of cans will be 1 week after delivery depending on number of cans\n" +
                                    "4.Users will be notified about return of cans.\n" +
                                    "5.More than 3 blackmarks on delivery will remove you from thuli\n" +
                                    "\n" +
                                    "Have a happy journey with Thuli";
                        }
                        else
                        {
                            inst="Sorry not a licensed vendor";
                        }
                        intent.putExtra("inst",inst);
                        startActivity(intent);

                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.e("The read failed: " ,firebaseError.getMessage());
                    }
                });






            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
