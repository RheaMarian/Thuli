package ghost.vrithika.com.newthuli;

/**
 * Created by Vrithika on 18-03-2017.
 */

public class Vendor {
    public String id;
    public String pass;

    // Default constructor required for calls to
    // DataSnapshot.getValue(User.class)
    public Vendor() {
    }

    public Vendor(String id, String pass) {
        this.id = id;
        this.pass = pass;
    }
}
