package ghost.vrithika.com.newthuli;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class AfterCustReg extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_cust_reg);
        Intent intent=getIntent();

        final String inst=intent.getStringExtra("inst");

        TextView tinst=(TextView)findViewById(R.id.textView15);

        tinst.setText(inst);
    }
}
