package ghost.vrithika.com.newthuli;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class VendorLoginReg extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_login_reg);


        Intent intent=getIntent();
        final String utype=intent.getStringExtra("usertype");

        final EditText euid=(EditText)findViewById(R.id.uid);
        final EditText eps=(EditText)findViewById(R.id.ps);

        final FirebaseDatabase mFirebaseInstance = FirebaseDatabase.getInstance();
        final DatabaseReference mFirebaseDatabase = mFirebaseInstance.getReference(utype);

        Button blog=(Button)findViewById(R.id.blog);
        final Context context=this;
        blog.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                mFirebaseDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snap) {

                        String uid=euid.getText().toString();
                        String ps=eps.getText().toString();
                        if(utype.equalsIgnoreCase("Vendors"))
                        {
                            NewVendor vendor=null;
                            for(DataSnapshot singleSnapshot : snap.getChildren()) {
                                vendor = singleSnapshot.getValue(NewVendor.class);
                                if (uid.equals(vendor.id) && ps.equals(vendor.pass)) {

                                    Spinner spinner = (Spinner) findViewById(R.id.city);
                                    final String city = spinner.getSelectedItem().toString();
                                    Intent intent;
                                    intent = new Intent(context, AfterVendorLogin.class);
                                    intent.putExtra("usertype", utype);
                                    intent.putExtra("city", city);
                                    intent.putExtra("uid", uid);
                                    intent.putExtra("ps", ps);

                                    startActivity(intent);
                                }
                            }
                        }
                        else
                        {
                            Customer customer=null;
                            for(DataSnapshot singleSnapshot : snap.getChildren()){
                                customer = singleSnapshot.getValue(Customer.class);
                                if((uid.equals(customer.id))&&(ps.equals(customer.pass))) {

                                    Spinner spinner = (Spinner) findViewById(R.id.city);
                                    final String city = spinner.getSelectedItem().toString();
                                    Intent intent;
                                    intent = new Intent(context, CustAfterLogin.class);
                                    intent.putExtra("usertype",utype);
                                    intent.putExtra("city",city);
                                    intent.putExtra("uid",uid);
                                    intent.putExtra("ps",ps);

                                    startActivity(intent);
                                }
                            }
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.e("The read failed: " ,firebaseError.getMessage());
                    }
                });

            }
        });
        Button breg=(Button)findViewById(R.id.breg);

        breg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Spinner spinner=(Spinner)findViewById(R.id.city);
                final String city=spinner.getSelectedItem().toString();

                String uid=euid.getText().toString();
                String ps=eps.getText().toString();
                Intent intent;

                // do not froget to update registry in db
                if(utype.equalsIgnoreCase("Vendors"))
                {
                     intent=new Intent(context,VendorNewRegister.class);
                }
                else
                {
                    intent=new Intent(context,CustReg.class);
                }
                intent.putExtra("usertype",utype);
                intent.putExtra("city",city);
                intent.putExtra("uid",uid);
                intent.putExtra("ps",ps);

                startActivity(intent);
            }
        });
    }
}
