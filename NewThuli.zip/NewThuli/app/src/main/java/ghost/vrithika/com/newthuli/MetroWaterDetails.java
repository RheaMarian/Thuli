package ghost.vrithika.com.newthuli;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MetroWaterDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metro_water_details);
        Intent intent=getIntent();
        String add=intent.getStringExtra("add");
        int qty=Integer.parseInt(add);

        final String zone = intent.getStringExtra("zone");
        final String city = intent.getStringExtra("city");
        final String uid = intent.getStringExtra("uid");
        final String ps = intent.getStringExtra("ps");

        TextView c10=(TextView)findViewById(R.id.textView10);
        //int price;
        //price=qty*50;
       // c10.setText(Integer.toString(price));
        if(add.equals("6000"))
        c10.setText("400");
        else if(add.equals("9000"))
        c10.setText("600");
    }
}