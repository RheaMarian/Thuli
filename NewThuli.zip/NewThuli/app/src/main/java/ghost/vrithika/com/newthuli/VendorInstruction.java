package ghost.vrithika.com.newthuli;

        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.widget.TextView;

public class VendorInstruction extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_instruction);
        Intent intent=getIntent();

        final String inst=intent.getStringExtra("inst");

        TextView tinst=(TextView)findViewById(R.id.tinst);

        tinst.setText(inst);
    }
}
