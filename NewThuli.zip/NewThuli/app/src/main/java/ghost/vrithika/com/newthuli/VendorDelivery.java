package ghost.vrithika.com.newthuli;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class VendorDelivery extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_delivery);Intent intent=getIntent();
        Button bd=(Button)findViewById(R.id.bd);
        Button bb=(Button)findViewById(R.id.bb);
        Button bcan=(Button)findViewById(R.id.bcan);
        final String uid=intent.getStringExtra("uid");
        final String zone=intent.getStringExtra("zone");
        final String city =intent.getStringExtra("city");
        final String ps=intent.getStringExtra("ps");

        TextView res=(TextView)findViewById(R.id.tinit);

        res.setText(uid+" "+zone+" "+city+" "+ps);

        final Context context=this;
        intent=new Intent(context,ToDeliver.class);


        bd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent=new Intent(context,ToDeliver.class);


                intent.putExtra("uid",uid);
                intent.putExtra("zone",zone);
                intent.putExtra("city",city);
                intent.putExtra("ps",ps);
                intent.putExtra("where","init");

                startActivity(intent);
            }
        });

        bb.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent=new Intent(context,Blackmark.class);


                intent.putExtra("uid",uid);
                intent.putExtra("zone",zone);
                intent.putExtra("city",city);
                intent.putExtra("ps",ps);
                intent.putExtra("where","init");

                startActivity(intent);
            }
        });

        bcan.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent=new Intent(context,Custcan.class);


                intent.putExtra("uid",uid);
                intent.putExtra("zone",zone);
                intent.putExtra("city",city);
                intent.putExtra("ps",ps);
                intent.putExtra("where","init");

                startActivity(intent);
            }
        });
    }
}

