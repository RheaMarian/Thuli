package ghost.vrithika.com.newthuli;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;

public class Custcan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custcan);
        Button bd=(Button)findViewById(R.id.bd);
        Button bb=(Button)findViewById(R.id.bb);
        Button bcan=(Button)findViewById(R.id.bcan);

        Intent intent=getIntent();
        final String uid=intent.getStringExtra("uid");
        final String zone=intent.getStringExtra("zone");
        final String city =intent.getStringExtra("city");
        final String ps=intent.getStringExtra("ps");
        final String where=intent.getStringExtra("where");

        Calendar c= Calendar.getInstance();
        final String hr=Integer.toString(c.get(Calendar.HOUR_OF_DAY));
        final String min=Integer.toString(c.get(Calendar.MINUTE));



        final Button bdelv1=(Button)findViewById(R.id.byes1);
        final Button bdelv2=(Button)findViewById(R.id.byes2);
        final Button bdelv3=(Button)findViewById(R.id.byes3);
        final TextView tsuccess=(TextView)findViewById(R.id.tsuccess);

        tsuccess.setText("cur time: "+hr+" "+min);

        bdelv1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                TextView tadd1=(TextView)findViewById(R.id.tadd1);
                TextView tid1=(TextView)findViewById(R.id.tid1);

                //for this booking id get otp
                //make can as 1 and delete booking record

                EditText epass1=(EditText)findViewById(R.id.epass1);

                tsuccess.setText("yes");

            }

        });

        bdelv2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                TextView tadd2=(TextView)findViewById(R.id.tadd2);
                TextView tid2=(TextView)findViewById(R.id.tid2);

                //for this booking id get otp
                //make can as 1 and delete booking record

                EditText epass2=(EditText)findViewById(R.id.epass2);

                tsuccess.setText("no");

            }

        });

        bdelv3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                TextView tadd3=(TextView)findViewById(R.id.tadd3);
                TextView tid3=(TextView)findViewById(R.id.tid3);

                //for this booking id get otp
                //make can as 1 and delete booking record

                EditText epass3=(EditText)findViewById(R.id.epass3);

                tsuccess.setText("yo");
            }

        });

        final Context context=this;
        bd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent=new Intent(context,ToDeliver.class);


                intent.putExtra("uid",uid);
                intent.putExtra("zone",zone);
                intent.putExtra("city",city);
                intent.putExtra("ps",ps);
                intent.putExtra("where","Custcan");

                startActivity(intent);
            }
        });

        bb.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent=new Intent(context,Blackmark.class);


                intent.putExtra("uid",uid);
                intent.putExtra("zone",zone);
                intent.putExtra("city",city);
                intent.putExtra("ps",ps);
                intent.putExtra("where","Custcan");

                startActivity(intent);
            }
        });

        bcan.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent=new Intent(context,Custcan.class);


                intent.putExtra("uid",uid);
                intent.putExtra("zone",zone);
                intent.putExtra("city",city);
                intent.putExtra("ps",ps);
                intent.putExtra("where","Custcan");

                startActivity(intent);
            }
        });
    }
}
