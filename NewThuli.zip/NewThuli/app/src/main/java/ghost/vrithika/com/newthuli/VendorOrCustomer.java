package ghost.vrithika.com.newthuli;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class VendorOrCustomer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_or_customer);
        final Button bv=(Button)findViewById(R.id.bv);
        final Button bc=(Button)findViewById(R.id.bc) ;
        final Context context=this;
        bv.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,VendorLoginReg.class);
                String n= bv.getText().toString();
                intent.putExtra("usertype",n);
                startActivity(intent);

            }
        });

        bc.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,VendorLoginReg.class);
                String n= bc.getText().toString();
                intent.putExtra("usertype",n);
                startActivity(intent);
            }
        });
    }
}
