package ghost.vrithika.com.newthuli;

/**
 * Created by Vrithika on 18-03-2017.
 */

public class LicensedVendors {
    public String id;
    public String name;
    public String phno;

    // Default constructor required for calls to
    // DataSnapshot.getValue(User.class)
    public LicensedVendors() {
    }

    public LicensedVendors(String id, String name,String phno) {
        this.id = id;
        this.name = name;
        this.phno=phno;
    }
}
