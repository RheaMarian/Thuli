package ghost.vrithika.com.newthuli;

/**
 * Created by Vrithika on 18-03-2017.
 */

public class Customer {
    public String id;
    public String pass;
    public String zone;
    public String add;
    public String phno;

    // Default constructor required for calls to
    // DataSnapshot.getValue(User.class)
    public Customer() {
    }

    public Customer(String id, String pass,String zone,String add,String phno) {
        this.id = id;
        this.pass = pass;
        this.zone = zone;
        this.add = add;
        this.phno = phno;
    }
}
