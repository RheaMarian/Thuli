package ghost.vrithika.com.newthuli;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CustReg extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cust_reg);
        Intent intent=getIntent();
        final String utype=intent.getStringExtra("usertype");
        final String city=intent.getStringExtra("city");
        final String uid=intent.getStringExtra("uid");
        final String ps=intent.getStringExtra("ps");

        Spinner spinner = (Spinner) findViewById(R.id.spinner2);

        // TextView ctv=(TextView)findViewById(R.id.details);
        spinner.setOnItemSelectedListener(this);
        List<String> categories = new ArrayList<String>();
        if(city.equalsIgnoreCase("Chennai"))
        {

            categories.add("Thiruvottiyur");
            categories.add("Manali");
            categories.add("Madhavaram");
            categories.add("Tondiarpet");
            categories.add("Royapuram");
            categories.add("Thiruvikanagar");
            categories.add("Ambattur");
            categories.add("Annanagar");
            categories.add("Teynampet");
            categories.add("Kodambakkam");
            categories.add("Valasaravakkam");
            categories.add("Alandur");
            categories.add("Adyar");
            categories.add("Perungudi");
            categories.add("Sholinganallur");
        }
        if(city.equalsIgnoreCase("Mumbai"))
        {
            categories.add("Mumbai");
        }

        if(city.equalsIgnoreCase("Kolkata"))
        {
            categories.add("Kolkata");
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);


        final Context context=this;

        Button benter=(Button)findViewById(R.id.benter);
        benter.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Spinner spinner=(Spinner)findViewById(R.id.spinner2);
                final String zone=spinner.getSelectedItem().toString();

                Intent intent=new Intent(context,AfterCustReg.class);

                String inst;
                int flag=2;
                if(flag==1)
                {
                    inst="Registration SUCCESSFUL!!\n" +
                            "\n" +
                            "Have a happy journey with Thuli";
                }
                else
                {
                    inst="Please Register";
                }
                intent.putExtra("inst",inst);
                startActivity(intent);

            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}