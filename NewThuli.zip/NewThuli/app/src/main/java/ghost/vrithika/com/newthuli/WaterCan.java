package ghost.vrithika.com.newthuli;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class WaterCan extends AppCompatActivity {
    Button b1;
    EditText ent1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water_can);
        b1=(Button)findViewById(R.id.button);
        ent1=(EditText)findViewById(R.id.editText);
        TextView res=(TextView)findViewById(R.id.textView2);

        Intent intent=getIntent();
        final String zone = intent.getStringExtra("zone");
        final String city = intent.getStringExtra("city");
        final String uid = intent.getStringExtra("uid");
        final String ps = intent.getStringExtra("ps");
        res.setText(uid+" "+ps+" "+city+" "+zone);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            String s=ent1.getText().toString();
                Intent myIntent = new Intent(WaterCan.this,CanDetails.class);

                myIntent.putExtra("s",s);
                myIntent.putExtra("city",city);
                myIntent.putExtra("zone",zone);
                myIntent.putExtra("uid",uid);
                myIntent.putExtra("ps",ps);
                startActivity(myIntent);
            }
        });
    }
}

