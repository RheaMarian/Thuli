package ghost.vrithika.com.newthuli;

/**
 * Created by Vrithika on 18-03-2017.
 */

public class NewVendor {
    public String id;
    public String pass;
    public String bm;

    // Default constructor required for calls to
    // DataSnapshot.getValue(User.class)
    public NewVendor() {
    }

    public NewVendor(String id, String pass,String bm) {
        this.id = id;
        this.pass = pass;
        this.bm=bm;
    }
}
