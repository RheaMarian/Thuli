package ghost.vrithika.com.newthuli;

/**
 * Created by Vrithika on 18-03-2017.
 */

public class Details {
    public String vid;
    public String bid;
    public String btime;
    public String otp1;
    public String otp2;
    public String buyadd;
    public String buyph;
    public String del;
    public String can;
    public String cid;
    public String noc;
    public String price;

    // Default constructor required for calls to
    // DataSnapshot.getValue(User.class)
    public Details() {
    }

    public Details(String vid, String bid,String btime,String otp1,String otp2,String buyadd,String buyph,String del,String can,String cid,String noc,String price) {
        this.vid = vid;
        this.bid = bid;
        this.btime = btime;
        this.otp1 = otp1;
        this.otp2 = otp2;
        this.buyadd = buyadd;
        this.buyph = buyph;
        this.del = del;
        this.can = can;
        this.cid = cid;
        this.noc = noc;
        this.price=price;
    }
}
