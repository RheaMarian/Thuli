package ghost.vrithika.com.newthuli;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class MetroWater extends AppCompatActivity {
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metro_water);
        b1= (Button) findViewById(R.id.button4);

        Intent intent=getIntent();
        final String zone = intent.getStringExtra("zone");
        final String city = intent.getStringExtra("city");
        final String uid = intent.getStringExtra("uid");
        final String ps = intent.getStringExtra("ps");


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Context context = getApplicationContext();


                CheckBox ck = (CheckBox) findViewById(R.id.checkBox);
                CheckBox ck1 = (CheckBox) findViewById(R.id.checkBox2);
                String add1 = "";
                if (ck.isChecked())
                    add1 = add1 + ck.getText().toString();

                if (ck1.isChecked())
                    add1 = add1 + ck1.getText().toString();
                Intent myIntent = new Intent(MetroWater.this, MetroWaterDetails.class);
                myIntent.putExtra("add", add1);
                myIntent.putExtra("city",city);
                myIntent.putExtra("zone",zone);
                myIntent.putExtra("uid",uid);
                myIntent.putExtra("ps",ps);
                startActivity(myIntent);
            }



        });
    }
}