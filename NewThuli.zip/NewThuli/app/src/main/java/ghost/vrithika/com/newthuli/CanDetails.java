package ghost.vrithika.com.newthuli;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.util.Calendar;
import java.util.Random;

public class CanDetails extends AppCompatActivity {
    int count,b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_can_details);
        Intent intent = getIntent();
        final FirebaseDatabase mFirebaseInstance = FirebaseDatabase.getInstance();
        final DatabaseReference mFirebaseDatabase = mFirebaseInstance.getReference("Customers");

        final String zone = intent.getStringExtra("zone");
        final String city = intent.getStringExtra("city");
        final String uid = intent.getStringExtra("uid");
        final String ps = intent.getStringExtra("ps");
        final String q=intent.getStringExtra("s");
        int qty=Integer.parseInt(q);
        TextView t= (TextView)findViewById(R.id.textView11);
        final TextView t1= (TextView)findViewById(R.id.textView8);
        final TextView t2= (TextView)findViewById(R.id.textView9);
        final TextView t3= (TextView)findViewById(R.id.textView14);

        final int price;
        price=qty*50;
        t.setText(Integer.toString(price));

        mFirebaseDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snap) {
                for (DataSnapshot singleSnapshot : snap.getChildren()) {
                    final Customer customer = singleSnapshot.getValue(Customer.class);
                    if ((uid.equals(customer.id)) && (ps.equals(customer.pass))) {
                        final int otp1,otp2;
                        Random random=new Random();
                        otp1=100+random.nextInt(800);
                        otp2=100+random.nextInt(800);
                        Calendar c=Calendar.getInstance();
                        final String h=Integer.toString(c.get(Calendar.HOUR_OF_DAY));
                        final String m=Integer.toString(c.get(Calendar.MINUTE));




                        final DatabaseReference mFirebaseDatab = mFirebaseInstance.getReference("To be delivered");
                        mFirebaseDatab.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot snap) {
                                Details detail = null;
                                b=0;
                                for (DataSnapshot singleSnapshot : snap.getChildren()) {
                                    detail = singleSnapshot.getValue(Details.class);
                                    if(b<Integer.parseInt(detail.bid))
                                        b=Integer.parseInt(detail.bid);
                                }
                                b++;


                               /* final DatabaseReference mFirebaseData = mFirebaseInstance.getReference(zone);
                                mFirebaseData.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot snap) {
                                        Vendor vendor = null;
                                        count=0;
                                        for (DataSnapshot singleSnapshot : snap.getChildren()) {
                                            vendor = singleSnapshot.getValue(Vendor.class);
                                            count++;

                                        }
                                    }
                                    @Override
                                    public void onCancelled(DatabaseError firebaseError) {
                                        Log.e("The read failed: " ,firebaseError.getMessage());
                                    }
                                });*/


                              //  final int d=b % Integer.parseInt(t2.getText().toString());



                                final DatabaseReference mFirebaseDat = mFirebaseInstance.getReference(zone);
                                mFirebaseDat.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(DataSnapshot snap) {
                                         Vendor vendor1 = null;
                                        int c=0;

                                        for (DataSnapshot singleSnapshot : snap.getChildren()) {
                                            vendor1 = singleSnapshot.getValue(Vendor.class);
                                            c++;
                                            if(c==1){
                                                Details details=new Details(vendor1.id,Integer.toString(b),h+":"+m,Integer.toString(otp1),Integer.toString(otp2),customer.add,customer.phno,"0","0",uid,q,Integer.toString(price));
                                                DatabaseReference mFirebaseDatabase1 = mFirebaseInstance.getReference("To be delivered");
                                                String userId = mFirebaseDatabase1.push().getKey();
                                                mFirebaseDatabase1.child(userId).setValue(details);
                                                break;
                                            }
                                        }
                                    }
                                    @Override
                                    public void onCancelled(DatabaseError firebaseError) {
                                        Log.e("The read failed: " ,firebaseError.getMessage());
                                    }
                                });



                                t1.setText(Integer.toString(b));
                                t2.setText(Integer.toString(otp1));
                                t3.setText(Integer.toString(otp2));

                            }
                            @Override
                            public void onCancelled(DatabaseError firebaseError) {
                                Log.e("The read failed: " ,firebaseError.getMessage());
                            }
                        });


                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError firebaseError) {
                Log.e("The read failed: " ,firebaseError.getMessage());
            }
        });


    }
}
